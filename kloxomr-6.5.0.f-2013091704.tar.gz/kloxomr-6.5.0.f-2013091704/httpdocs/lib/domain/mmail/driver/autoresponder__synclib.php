<?php 

class autoresponder__sync extends lxDriverClass {


}

