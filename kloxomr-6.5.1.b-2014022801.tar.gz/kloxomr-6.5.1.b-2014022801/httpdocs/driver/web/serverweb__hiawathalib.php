<?php

include_once("serverweb__lib.php");

class serverweb__hiawatha extends serverweb__
{
	function __construct()
	{
		parent::__construct();
	}
}

