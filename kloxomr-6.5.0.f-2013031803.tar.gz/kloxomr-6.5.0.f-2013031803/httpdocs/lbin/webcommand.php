<?php 
chdir("..");
include_once "htmllib/lib/include.php";

webcommandline_main();
