	<link href="/panel/css/common.css" rel="stylesheet" type="text/css" />
	<link href="/panel/css/admin_login.css" rel="stylesheet" type="text/css" />

	<script language="javascript" src="/panel/js/login.js"></script>
	<script language="javascript" src="/panel/js/preop.js"></script>
	<script language="javascript" src="/panel/js/lxa.js"></script>
