<?php 

include_once "panel/coredisplaylib.php";
