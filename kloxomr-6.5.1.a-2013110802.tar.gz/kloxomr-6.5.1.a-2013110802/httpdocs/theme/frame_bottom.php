<?php

chdir("../");

include_once "lib/html/displayinclude.php";
// initProgram();

?>
<head>
	<title> bottom frame </title>
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<link href="/theme/css/header.css" rel="stylesheet" type="text/css"/>
	<link href="/theme/css/common.css" rel="stylesheet" type="text/css"/>

	<?php
	$ghtml->print_jscript_source("theme/js/lxa.js");
	?>

</head>
<body topmargin="0" leftmargin="0" bottommargin="0" rightmargin="0">
<div id="statusbar"
     style='background:#f0f0ff; scroll:auto; height:100%; width:100%; border-top:1px solid #aaaacf; margin:0 0 0 0: vertical-align:top; text-align:top'></div>
</body>
