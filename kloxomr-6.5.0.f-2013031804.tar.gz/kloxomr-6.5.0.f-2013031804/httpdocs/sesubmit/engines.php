<?php

// welcome to the engines configuration page ;)
// atm "AllTheWeb" has been disabled due to problems with its submission page wanting the full screen which stops the script... :(

//	"AllTheWeb",                  =>             //	"http://www.ussc.alltheweb.com/add_url.php3?url=[>URL<]&email=[>EMAIL<]",                                                                                        
$enginelist = array(
        //"Altavista"              =>                     "http://add-url.altavista.com/cgi-bin/newurl?ad=1&q=[>URL<]",                                                                                                
	"Altavista DE"               =>                     "http://www.altavista.de/newurl.jsp?url=[>URL<]",                                                                                                            
        "Altavista UK"           =>                     "http://uk.altavista.com/newurl.jsp?ad=1&url=[>URL<]",                                                                                                       
        "Anzwers"                =>                     "http://www.Anzwers.com/cgi-bin/print_addurl.pl?Submit=Submit&url=[>URL<]&email=[>EMAIL<]",                                                                  
        "Canada"                 =>                     "http://www.canada.com/search/web/addurl.asp?AddURL2=[>URL<]&email=[>EMAIL<]&todo=add&GO=search&x=13&y=16",                                                  
	"Direct Hit"                 =>             	"http://www.directhit.com/fcgi-bin/DirectHitWeb.fcg?fmt=disp&template=addurl&src=DH_ADDURL&URL=[>URL<]&email=[>EMAIL<]",                           
        "Excite"                 =>                     "http://www.excite.com/cgi/add_url.cgi?look=excite&url=[>URL<]&email=[>EMAIL<]",                                                                             
	"Excite UK"                  =>             	"http://www.excite.co.uk/cgi/ls_add_url.cgi?look=excite&ex_use=1&url=[>URL<]&email=[>EMAIL<]",                                                                   
        "Fireball"               =>                     "http://www.fireball.de/fcgi/register.fcg?action=register&url=[>URL<]&SUBMIT=URL+melden",                                                                    
        "Go"                     =>                     "http://www.go.com/AddUrl/AddingURL?url=[>URL<]&CAT=Add/Update%20Site&sv=AD&lk=noframes",                                                                    
        "Google"                 =>                     "http://www.google.com/addurl?q=[>URL<]&dq=",                                                                                                                
	"Google DE"                  =>             	"http://www.google.de/addurl?q=[>URL<]&dq=",                                                                                                                     
        "Hotbot"                 =>                     "http://www.hotbot.com/addurl.asp?newurl=[>URL<]&MM=1&output=success&email=[>EMAIL<]",                                                                       
        "Infomak"                =>                     "http://www.infomak.com/add_url.sh?Page=url&url=[>URL<]",                                                                                                    
        "Infoseek"               =>                     "http://www.infoseek.com/AddUrl/AddingURL?sv=IS&lk=noframes&nh=10&url=[>URL<]&CAT=Add/Update+URL",                                                           
        "Lycos"                  =>                     "http://www.lycos.com/cgi-bin/spider_now.pl?query=[>URL<]&email=[>EMAIL<]",                                                                                  
	"Lycos EU"                   =>                     "http://spidernow.lycos.com/cgi-bin/spidernow-EU.pl?query=[>URL<]&email=[>EMAIL<]&submit=Url+anmelden",                                                      
	"National Directory"         =>             	"http://www.nationaldirectory.com/addurl.cgi?url=[>URL<]",                                                                                                       
	"Northernlight"              =>                     "http://urls.northernlight.com/cgi-bin/urlsubmit.pl?page=[>URL<]&contact=Webmaster&email=[>EMAIL<]",                                                         
        "Voila"                  =>                     "http://www.voila.fr/submit?url=[>URL<]&email=[>EMAIL<]&submit2=Soumettre",                                                                                  
        "Web Crawler"            =>                     "http://www.webcrawler.com/cgi-bin/add_url_new.cgi?action=add&url=[>URL<]?url=[>URL<]&email=[>EMAIL<]&country=US&brand=webcrawler&look=excite&channel=local",
        "Web Top"                =>                     "http://www.webtop.com/cgi-bin/addurl?NEWURL=[>URL<]&EMAIL=[>EMAIL<]",                                                                                       
	"Web Wombat"                 =>                     "http://www.webwombat.com.au/Wregister?newurl=[>URL<]&email=[>EMAIL<]&submit=Register",                                                                      
        "WhatUSeek"               =>                     "http://whatuseek.com/cgi-bin/addurl?submit=Add+This+[>URL<]&url=[>URL<]&email=[>EMAIL<]"                                                                    
);

