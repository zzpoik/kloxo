#!/bin/sh
$* 2>>/var/log/kloxo/smtp.log
