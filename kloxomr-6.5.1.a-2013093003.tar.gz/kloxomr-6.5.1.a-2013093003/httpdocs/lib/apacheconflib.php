<?php 

class apacheconf extends lxdb {

static $__desc = array("", "",  "apache_config");
static $__desc_nname = array("", "",  "apache_config");

}
