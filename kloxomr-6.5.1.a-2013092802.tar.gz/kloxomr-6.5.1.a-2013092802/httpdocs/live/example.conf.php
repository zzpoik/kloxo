<?php 

$chanbase = "kloxo";
$redirect = 1;

$g_login = 1;

