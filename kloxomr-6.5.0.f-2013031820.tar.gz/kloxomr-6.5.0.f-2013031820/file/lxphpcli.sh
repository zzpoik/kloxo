#!/bin/sh

/usr/local/lxlabs/ext/php/bin/php -c /usr/local/lxlabs/ext/php/etc/php.ini $*
