<?php 

include_once("dirprotect__lib.php");

class dirprotect__nginx extends dirprotect__
{

}
