#!/bin/sh

export HOME=/root
export ZDOTDIR=/root/.etc
zsh


