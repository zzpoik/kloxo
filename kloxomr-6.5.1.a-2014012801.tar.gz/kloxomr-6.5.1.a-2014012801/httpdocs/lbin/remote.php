<?php 
chdir("..");
include_once "lib/html/include.php";
include_once "lib/html/remotelib.php";

remote_main();

