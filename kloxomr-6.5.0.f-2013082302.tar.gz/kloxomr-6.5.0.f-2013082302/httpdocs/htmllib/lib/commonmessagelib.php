<?php 

$g_commonhelp['ippool_updateform_update_post'] = 'ippool_addform__post';
$g_commonhelp['vps_addform_openvz_post'] = 'vps_addform__post';
$g_commonhelp['vps_addform_xen_post'] = 'vps_addform__post';
$g_commonhelp['redirect_a_addform_local_post'] = 'redirect_a_list__post';
$g_commonhelp['redirect_a_addform_remote_post'] = 'redirect_a_list__post';
$g_commonhelp['addondomain_addform_parked_post'] = 'addondomain_list__post';
$g_commonhelp['addondomain_addform_redirect_post'] = 'addondomain_list__post';

