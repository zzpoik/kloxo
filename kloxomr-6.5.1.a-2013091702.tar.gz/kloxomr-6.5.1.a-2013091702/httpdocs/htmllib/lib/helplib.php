<?php 

$__help['a'] = 'h';

