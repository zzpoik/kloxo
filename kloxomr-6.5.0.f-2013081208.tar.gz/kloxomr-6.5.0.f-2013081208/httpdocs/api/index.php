<?php 
chdir("../");
include_once "htmllib/lib/displayinclude.php";

webcommandline_main();
