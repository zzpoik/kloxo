<?php 

include_once "theme/coredisplaylib.php";

log_log("ajax", var_export($_REQUEST, true));


include_once "lib/html/ajaxcore.php";

//log_log("ajax", var_export($_COOKIE, true));


