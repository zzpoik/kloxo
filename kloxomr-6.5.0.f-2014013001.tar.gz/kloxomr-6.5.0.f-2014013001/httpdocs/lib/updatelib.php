<?php


//--- move to kloxo/httpdocs/htmllib/lib/updatelib.php
// since version 6.1.7
