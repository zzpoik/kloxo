<?php 

include_once "lib/php/gbllib.php";

class Gbl extends Gbllib {

}
