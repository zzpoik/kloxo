#!/bin/sh

#    Kloxo-MR - Hosting Control Panel
#
#    Copyright (C) 2013 - MRatWork
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# MRatWork - Kloxo-MR patch Installer
#
# Version: 1.0 (2013-01-11 - by Mustafa Ramadhan <mustafa@bigraf.com>)
#

echo "Start pack..."

yum install zip unzip -y

cp -rf ./kloxo/install/installer.sh ./

ver=`cat ./kloxo/bin/kloxoversion`

mv ./kloxo ./kloxomr-patch-$ver

### 4. zipped process
tar -czf kloxomr-patch-$ver.tar.gz "./kloxomr-patch-$ver/"


rm -rf ./kloxomr-patch-$ver > /dev/null 2>&1
rm -rf ./kloxo-install > /dev/null 2>&1
rm -rf ./install > /dev/null 2>&1

echo
echo "Now you can run 'sh ./installer.sh' for installing"
echo
echo "... the end"
