<?php

include_once "htmllib/lib/driver_definecore.php";
$gl_class_array['autoresponder__qmail'] = "lib/domain/mmail/driver/autoresponder__qmaillib.phps";
//--// $gl_class_array['autoresponder__mailenable'] = "lib/domain/mmail/driver/autoresponder__mailenablelib.php";

$gl_class_array['domaintraffichistory__apache'] = "lib/domain//driver/domaintraffichistory__apachelib.php";

$gl_class_array['mailinglist__mailman'] = "lib/domain/mmail/driver/mailinglist__mailmanlib.php";
$gl_class_array['listsubscribe__mailman'] = "lib/domain/mmail/driver/listsubscribe__mailmanlib.php";

$gl_class_array['web__apache'] = "lib/domain/web/driver/web__apachelib.php";
$gl_class_array['web__lighttpd'] = "lib/domain/web/driver/web__lighttpdlib.php";
$gl_class_array['web__nginx'] = "lib/domain/web/driver/web__nginxlib.php";
$gl_class_array['web__hiawatha'] = "lib/domain/web/driver/web__hiawathalib.php";
$gl_class_array['web__openlitespeed'] = "lib/domain/web/driver/web__openlitespeedlib.php";

$gl_class_array['web__lighttpdproxy'] = "lib/domain/web/driver/web__lighttpdproxylib.php";
$gl_class_array['web__nginxproxy'] = "lib/domain/web/driver/web__nginxproxylib.php";
$gl_class_array['web__hiawathaproxy'] = "lib/domain/web/driver/web__hiawathaproxylib.php";
$gl_class_array['web__openlitespeedproxy'] = "lib/domain/web/driver/web__openlitespeedproxylib.php";

$gl_class_array['webcache__varnish'] =  "lib/domain/webcache/driver/webcache__varnishlib.php";
$gl_class_array['webcache__trafficserver'] =  "lib/domain/webcache/driver/webcache__trafficserverlib.php";
$gl_class_array['webcache__none'] =  "lib/domain/webcache/driver/webcache__nonelib.php";

$gl_class_array['webtraffic__apache'] = "lib/domain/web/driver/webtraffic__apachelib.php";
$gl_class_array['webtraffic__lighttpd'] = "lib/domain/web/driver/webtraffic__lighttpdlib.php";
$gl_class_array['webtraffic__nginx'] = "lib/domain/web/driver/webtraffic__nginxlib.php";

$gl_class_array['mailtraffic__qmail'] = "lib/domain/mmail/driver/mailtraffic__qmaillib.php";

$gl_class_array['installappsnapshot__sync'] = "lib/domain/web/driver/installappsnapshot__sync.phps";
$gl_class_array['davuser__lighttpd'] = "lib/domain/web/driver/davuser__lighttpdlib.php";

$gl_class_array['dirprotect__apache'] = "lib/domain/web/driver/dirprotect__apachelib.php";
$gl_class_array['dirprotect__lighttpd'] = "lib/domain/web/driver/dirprotect__lighttpdlib.php";
//--// $gl_class_array['dirprotect__iis'] = "lib/domain/web/driver/dirprotect__iislib.php";
$gl_class_array['dirprotect__nginx'] = "lib/domain/web/driver/dirprotect__nginxlib.php";
$gl_class_array['dirprotect__lighttpdproxy'] = "lib/domain/web/driver/dirprotect__lighttpdproxylib.php";
$gl_class_array['dirprotect__nginxproxy'] = "lib/domain/web/driver/dirprotect__nginxproxylib.php";

$gl_class_array['mmail__qmail'] = "lib/domain/mmail/driver/mmail__qmaillib.phps";
//--// $gl_class_array['mmail__mailenable'] = "lib/domain/mmail/driver/mmail__mailenablelib.php";
$gl_class_array['webmimetype__apache'] = "lib/domain/web/driver/mimehandler__apache.php";
$gl_class_array['webhandler__apache'] = "lib/domain/web/driver/mimehandler__apache.php";
$gl_class_array['mailaccount__qmail'] = "lib/domain/mmail/driver/mailaccount__qmaillib.phps";
$gl_class_array['mailforward__qmail'] = "lib/domain/mmail/driver/mailforward__qmaillib.phps";

$gl_class_array['installapp__linux'] = "lib/domain/web/driver/installapp__linuxlib.phps";
$gl_class_array['allinstallapp__linux'] = "lib/domain/web/driver/allinstallapp__linuxlib.phps";
//--// $gl_class_array['autoresponder__mailenable'] = "lib/domain/mmail/driver/autoresponder__mailenable.php";
//--// $gl_class_array['mailinglist__mailenable'] = "lib/domain/mmail/driver/mailinglist__mailenablelib.php";
//--// $gl_class_array['mailaccount__mailenable'] = "lib/domain/mmail/driver/mailaccount__mailenablelib.php";
$gl_class_array['mailinglist__ezmlm'] = "lib/domain/mmail/driver/mailinglist__ezmlmlib.phps";
$gl_class_array['listsubscribe__ezmlm'] = "lib/domain/mmail/driver/listsubscribe__ezmlmlib.php";
//--// $gl_class_array['listsubscribe__mailenable'] = "lib/domain/mmail/driver/listsubscribe__mailenablelib.php";
$gl_class_array['spam__spamassassin'] = "lib/domain/mmail/driver/spam__spamassassinlib.php";
$gl_class_array['spam__bogofilter'] = "lib/domain/mmail/driver/spam__bogofilterlib.php";
$gl_class_array['mailcontent__qmail'] = "lib/domain/mmail/driver/mailcontent__qmaillib.php";
$gl_class_array['mailqueue__qmail'] = "htmllib/lib/pserver/driver/mailqueue__qmaillib.php";

$gl_class_array['serverweb__apache'] = "lib/serverweb__apachelib.php";
$gl_class_array['serverweb__lighttpd'] = "lib/serverweb__lighttpdlib.php";
$gl_class_array['serverweb__nginx'] = "lib/serverweb__nginxlib.php";
$gl_class_array['serverweb__hiawatha'] = "lib/serverweb__hiawathalib.php";

$gl_class_array['serverweb__lighttpdproxy'] = "lib/serverweb__lighttpdproxylib.php";
$gl_class_array['serverweb__nginxproxy'] = "lib/serverweb__nginxproxylib.php";
$gl_class_array['serverweb__hiawathaproxy'] = "lib/serverweb__hiawathaproxylib.php";

$gl_class_array['rubyrails__linux'] = "lib/domain/web/driver/rubyrails__linuxlib.php";

