<?php 

class llog__Linux extends lxDriverClass {


}
